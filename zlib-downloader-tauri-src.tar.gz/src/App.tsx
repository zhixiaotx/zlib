import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { SearchSection } from './components/SearchSection';
import { DownloadQueue } from './components/DownloadQueue';
import { MirrorsManager } from './components/MirrorsManager';
import { LocalLibrary } from './components/LocalLibrary';
import { TauriPackagerModal } from './components/TauriPackagerModal';
import { SettingsTab } from './components/SettingsTab';
import { AISummaryModal } from './components/AISummaryModal';
import { Book, DownloadTask } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState('search');
  const [darkMode, setDarkMode] = useState(true);
  const [downloadTasks, setDownloadTasks] = useState<DownloadTask[]>([]);
  const [downloadedBooks, setDownloadedBooks] = useState<Book[]>([]);
  const [aiModalBook, setAiModalBook] = useState<Book | null>(null);

  // Sync dark mode class on html root
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // Simulate active download progress updates
  useEffect(() => {
    const interval = setInterval(() => {
      setDownloadTasks(prev =>
        prev.map(task => {
          if (task.status !== 'downloading') return task;
          const nextProgress = task.progress + Math.floor(Math.random() * 8) + 2;
          if (nextProgress >= 100) {
            // Task completed! Add to downloaded library
            return { ...task, progress: 100, status: 'completed', speed: '0 KB/s', eta: 'Done' };
          }
          const speeds = ['1.8 MB/s', '2.4 MB/s', '3.1 MB/s', '4.2 MB/s', '1.5 MB/s'];
          const etas = ['4s', '3s', '2s', '1s', '5s'];
          return {
            ...task,
            progress: nextProgress,
            speed: speeds[Math.floor(Math.random() * speeds.length)],
            eta: etas[Math.floor(Math.random() * etas.length)]
          };
        })
      );
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  // When tasks complete, sync downloaded books
  useEffect(() => {
    const completedTaskBookIds = downloadTasks
      .filter(t => t.status === 'completed')
      .map(t => t.bookId);

    // Fetch initial or add mock books corresponding to completed IDs
    // For simplicity, we can track books directly or fetch
  }, [downloadTasks]);

  const handleStartDownload = (book: Book) => {
    // Check if task already exists
    if (downloadTasks.some(t => t.bookId === book.id)) {
      setActiveTab('downloads');
      return;
    }

    const newTask: DownloadTask = {
      id: `task-${Date.now()}`,
      bookId: book.id,
      title: book.title,
      author: book.author,
      extension: book.extension,
      filesize: book.filesize,
      progress: 5,
      speed: '2.8 MB/s',
      eta: '6s',
      status: 'downloading',
      downloadedBytes: `1.2 MB`,
      mirrorUrl: 'https://singlelogin.re'
    };

    setDownloadTasks(prev => [newTask, ...prev]);
    setActiveTab('downloads');

    // Also add to downloaded library after simulation completes or right away for library view
    setTimeout(() => {
      setDownloadedBooks(prev => {
        if (prev.some(b => b.id === book.id)) return prev;
        return [book, ...prev];
      });
    }, 5000);
  };

  const handlePauseTask = (id: string) => {
    setDownloadTasks(prev =>
      prev.map(t => t.id === id ? { ...t, status: 'paused', speed: 'Paused' } : t)
    );
  };

  const handleResumeTask = (id: string) => {
    setDownloadTasks(prev =>
      prev.map(t => t.id === id ? { ...t, status: 'downloading', speed: '2.1 MB/s' } : t)
    );
  };

  const handleCancelTask = (id: string) => {
    setDownloadTasks(prev => prev.filter(t => t.id !== id));
  };

  const handleRemoveLibraryBook = (id: string) => {
    setDownloadedBooks(prev => prev.filter(b => b.id !== id));
  };

  const activeDownloadsCount = downloadTasks.filter(t => t.status === 'downloading').length;
  const downloadedBookIds = downloadedBooks.map(b => b.id);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        activeDownloadsCount={activeDownloadsCount}
      />

      <main className="flex-1 max-w-7xl w-full mx-auto px-6 py-8">
        {activeTab === 'search' && (
          <SearchSection
            onStartDownload={handleStartDownload}
            onOpenAISummary={(book) => setAiModalBook(book)}
            downloadedBookIds={downloadedBookIds}
          />
        )}

        {activeTab === 'downloads' && (
          <DownloadQueue
            tasks={downloadTasks}
            onPauseTask={handlePauseTask}
            onResumeTask={handleResumeTask}
            onCancelTask={handleCancelTask}
            onOpenFolder={() => alert('Simulated Tauri downloads folder opened: C:\\Users\\Public\\ZLibraryDownloads')}
          />
        )}

        {activeTab === 'library' && (
          <LocalLibrary
            downloadedBooks={downloadedBooks}
            onRemoveBook={handleRemoveLibraryBook}
            onOpenFolder={() => alert('Simulated Tauri library folder opened: C:\\Users\\Public\\ZLibraryDownloads')}
            onOpenAISummary={(book) => setAiModalBook(book)}
          />
        )}

        {activeTab === 'mirrors' && <MirrorsManager />}

        {activeTab === 'tauri' && <TauriPackagerModal />}

        {activeTab === 'settings' && <SettingsTab />}
      </main>

      {aiModalBook && (
        <AISummaryModal
          book={aiModalBook}
          onClose={() => setAiModalBook(null)}
        />
      )}
    </div>
  );
}
