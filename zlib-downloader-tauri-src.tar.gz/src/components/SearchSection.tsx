import React, { useState, useEffect } from 'react';
import { Search, Filter, Download, Sparkles, Star, FileText, Globe, CheckCircle2, ArrowRight } from 'lucide-react';
import { Book } from '../types';

interface SearchSectionProps {
  onStartDownload: (book: Book) => void;
  onOpenAISummary: (book: Book) => void;
  downloadedBookIds: string[];
}

export const SearchSection: React.FC<SearchSectionProps> = ({
  onStartDownload,
  onOpenAISummary,
  downloadedBookIds
}) => {
  const [query, setQuery] = useState('');
  const [language, setLanguage] = useState('all');
  const [extension, setExtension] = useState('all');
  const [books, setBooks] = useState<Book[]>([]);
  const [loading, setLoading] = useState(false);
  const [total, setTotal] = useState(0);

  const fetchBooks = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (query) params.append('q', query);
      if (language !== 'all') params.append('lang', language);
      if (extension !== 'all') params.append('ext', extension);

      const res = await fetch(`/api/zlib/search?${params.toString()}`);
      const data = await res.json();
      if (data.success) {
        setBooks(data.books);
        setTotal(data.total);
      }
    } catch (err) {
      console.error('Failed to search books', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBooks();
  }, [language, extension]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchBooks();
  };

  return (
    <div className="space-y-6">
      {/* Search Bar & Filters Card */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-sm">
        <form onSubmit={handleSearchSubmit} className="space-y-4">
          <div className="relative">
            <span className="absolute inset-y-0 left-0 flex items-center pl-4 pointer-events-none text-slate-400">
              <Search size={20} />
            </span>
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search by book title, author, ISBN, or keywords (e.g., Python, Microservices, 数据库)..."
              className="w-full pl-12 pr-32 py-3.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all font-medium"
            />
            <button
              type="submit"
              className="absolute right-2 top-2 bottom-2 px-6 bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded-lg transition-colors flex items-center gap-2 shadow"
            >
              <span>Search</span>
              <ArrowRight size={16} />
            </button>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-4 pt-2 border-t border-slate-100 dark:border-slate-800">
            <div className="flex flex-wrap items-center gap-3">
              <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 uppercase tracking-wider">
                <Filter size={14} />
                <span>Filters:</span>
              </div>

              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
                className="bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs rounded-lg px-3 py-2 font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="all">All Languages</option>
                <option value="English">English</option>
                <option value="Chinese">Chinese (中文)</option>
                <option value="German">German</option>
                <option value="Spanish">Spanish</option>
              </select>

              <select
                value={extension}
                onChange={(e) => setExtension(e.target.value)}
                className="bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs rounded-lg px-3 py-2 font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="all">All Formats (.pdf, .epub...)</option>
                <option value="pdf">PDF</option>
                <option value="epub">EPUB</option>
                <option value="mobi">MOBI</option>
              </select>
            </div>

            <div className="text-xs text-slate-500 font-mono">
              Found <span className="font-bold text-slate-900 dark:text-white">{total}</span> matching items in mirrored index
            </div>
          </div>
        </form>
      </div>

      {/* Book Results Grid */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((n) => (
            <div key={n} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 h-72 animate-pulse flex flex-col justify-between">
              <div className="space-y-3">
                <div className="h-5 bg-slate-200 dark:bg-slate-800 rounded w-3/4"></div>
                <div className="h-4 bg-slate-200 dark:bg-slate-800 rounded w-1/2"></div>
                <div className="h-16 bg-slate-200 dark:bg-slate-800 rounded w-full"></div>
              </div>
              <div className="h-10 bg-slate-200 dark:bg-slate-800 rounded w-full"></div>
            </div>
          ))}
        </div>
      ) : books.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-12 text-center">
          <div className="w-12 h-12 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center mx-auto text-slate-400 mb-4">
            <Search size={24} />
          </div>
          <h3 className="text-lg font-bold text-slate-900 dark:text-white">No books found</h3>
          <p className="text-sm text-slate-500 mt-1">Try refining your search query or switching active mirrors.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {books.map((book) => {
            const isDownloaded = downloadedBookIds.includes(book.id);
            return (
              <div
                key={book.id}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 flex flex-col justify-between hover:shadow-lg transition-all group"
              >
                <div>
                  <div className="flex items-start justify-between gap-4 mb-3">
                    <div>
                      <span className="inline-block px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800 mb-1">
                        {book.extension} · {book.filesize}
                      </span>
                      <h3 className="text-base font-bold text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors line-clamp-2">
                        {book.title}
                      </h3>
                    </div>
                  </div>

                  {/* Clean unboxed metadata (anti-slop rule compliant) */}
                  <div className="flex items-center gap-2 text-xs text-slate-500 mb-3">
                    <span className="font-medium text-slate-700 dark:text-slate-300">{book.author}</span>
                    <span aria-hidden="true">·</span>
                    <span>{book.year}</span>
                    <span aria-hidden="true">·</span>
                    <span>{book.publisher}</span>
                  </div>

                  <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-3 mb-4">
                    {book.description}
                  </p>
                </div>

                <div className="space-y-3 pt-4 border-t border-slate-100 dark:border-slate-800">
                  <div className="flex items-center justify-between text-xs text-slate-500">
                    <div className="flex items-center gap-1 text-amber-500 font-semibold">
                      <Star size={14} className="fill-current" />
                      <span>{book.rating}</span>
                    </div>
                    <span className="font-mono">{book.downloadsCount.toLocaleString()} downloads</span>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => onOpenAISummary(book)}
                      className="px-3 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-medium rounded-lg transition-colors flex items-center justify-center gap-1.5"
                    >
                      <Sparkles size={14} className="text-amber-500" />
                      <span>AI Summary</span>
                    </button>

                    <button
                      onClick={() => onStartDownload(book)}
                      disabled={isDownloaded}
                      className={`px-3 py-2 text-xs font-semibold rounded-lg transition-all flex items-center justify-center gap-1.5 shadow ${
                        isDownloaded
                          ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 cursor-default'
                          : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-indigo-600/30'
                      }`}
                    >
                      {isDownloaded ? (
                        <>
                          <CheckCircle2 size={14} />
                          <span>In Library</span>
                        </>
                      ) : (
                        <>
                          <Download size={14} />
                          <span>Download</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
