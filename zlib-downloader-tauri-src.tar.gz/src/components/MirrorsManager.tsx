import React, { useState, useEffect } from 'react';
import { Globe, RefreshCw, CheckCircle2, AlertTriangle, Shield } from 'lucide-react';
import { Mirror } from '../types';

export const MirrorsManager: React.FC = () => {
  const [mirrors, setMirrors] = useState<Mirror[]>([]);
  const [testing, setTesting] = useState(false);

  const fetchMirrors = async () => {
    try {
      const res = await fetch('/api/zlib/mirrors');
      const data = await res.json();
      if (data.success) {
        setMirrors(data.mirrors);
      }
    } catch (err) {
      console.error('Failed to fetch mirrors', err);
    }
  };

  useEffect(() => {
    fetchMirrors();
  }, []);

  const testMirrors = async () => {
    setTesting(true);
    try {
      const res = await fetch('/api/zlib/mirrors/test', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        setMirrors(data.mirrors);
      }
    } catch (err) {
      console.error('Failed to test mirrors', err);
    } finally {
      setTesting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Globe className="text-indigo-600" size={24} />
            <span>Z-Library Mirrors & Domain Routing</span>
          </h2>
          <p className="text-sm text-slate-500 mt-1">
            Manage official and community-maintained mirrors with automatic speed testing and load balancing.
          </p>
        </div>

        <button
          onClick={testMirrors}
          disabled={testing}
          className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-semibold rounded-lg transition-colors flex items-center gap-2 shadow"
        >
          <RefreshCw size={16} className={testing ? 'animate-spin' : ''} />
          <span>{testing ? 'Testing Latency...' : 'Test All Mirrors'}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {mirrors.map((mirror) => (
          <div
            key={mirror.id}
            className={`bg-white dark:bg-slate-900 border rounded-xl p-6 shadow-sm flex flex-col justify-between space-y-4 transition-all ${
              mirror.active
                ? 'border-indigo-600 dark:border-indigo-500 ring-2 ring-indigo-500/10'
                : 'border-slate-200 dark:border-slate-800'
            }`}
          >
            <div className="flex items-start justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${
                    mirror.status === 'online'
                      ? 'bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800'
                      : 'bg-amber-50 dark:bg-amber-950/50 text-amber-600 dark:text-amber-400 border border-amber-200 dark:border-amber-800'
                  }`}>
                    {mirror.status}
                  </span>
                  {mirror.active && (
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800">
                      Active Mirror
                    </span>
                  )}
                </div>
                <h3 className="text-lg font-mono font-bold text-slate-900 dark:text-white">{mirror.url}</h3>
              </div>

              <div className="text-right">
                <div className="text-xs text-slate-400 font-mono">Latency</div>
                <div className="text-sm font-mono font-bold text-slate-700 dark:text-slate-300">{mirror.latency}</div>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-xs text-slate-500">
                <Shield size={14} className="text-emerald-500" />
                <span>SSL Secured & Verified</span>
              </div>

              <button
                onClick={() => {
                  setMirrors(mirrors.map(m => ({ ...m, active: m.id === mirror.id })));
                }}
                disabled={mirror.active}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                  mirror.active
                    ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 cursor-default'
                    : 'bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300'
                }`}
              >
                {mirror.active ? 'Selected' : 'Use Mirror'}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
