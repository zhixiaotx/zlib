import React, { useState, useEffect } from 'react';
import { Terminal, Download, Copy, Check, FileCode, Cpu, Shield, ArrowRight } from 'lucide-react';

export const TauriPackagerModal: React.FC = () => {
  const [configFiles, setConfigFiles] = useState<Record<string, string>>({});
  const [activeFile, setActiveFile] = useState('src-tauri/tauri.conf.json');
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/tauri/config-files')
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          setConfigFiles(data.files);
        }
      })
      .catch(err => console.error('Failed to load tauri files', err))
      .finally(() => setLoading(false));
  }, []);

  const handleCopy = () => {
    if (configFiles[activeFile]) {
      navigator.clipboard.writeText(configFiles[activeFile]);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleDownloadBundle = () => {
    const blob = new Blob([JSON.stringify(configFiles, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'zlib-downloader-tauri-bundle.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Hero Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-indigo-500/30 rounded-2xl p-8 text-white shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 translate-x-12 -translate-y-12 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="max-w-3xl space-y-4 relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 text-xs font-mono border border-indigo-500/30">
            <Terminal size={14} />
            <span>Tauri v1.5 Native Desktop Framework</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Build Windows .EXE Portable & NSIS Installer
          </h2>
          <p className="text-sm text-slate-300 leading-relaxed">
            Tauri combines a Rust backend with web-based frontend (Vite + React) to deliver a blazing-fast, tiny (~15MB) desktop application. Below are the complete production configuration files and build steps to compile your Z-Library Downloader into a native Windows executable (`.exe`).
          </p>
          <div className="flex flex-wrap items-center gap-4 pt-2">
            <button
              onClick={handleDownloadBundle}
              className="px-5 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs rounded-xl shadow-lg shadow-indigo-600/30 transition-all flex items-center gap-2"
            >
              <Download size={16} />
              <span>Download Tauri Configuration Bundle</span>
            </button>
          </div>
        </div>
      </div>

      {/* Step-by-Step Build Guide */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-3 shadow-sm">
          <div className="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 font-mono font-bold flex items-center justify-center">
            01
          </div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">Install Rust & Node Toolchain</h3>
          <p className="text-xs text-slate-500 leading-relaxed">
            Ensure Node.js (&gt;= 18), Rust (`rustc` & `cargo`), and Microsoft Visual Studio C++ Build Tools are installed on your Windows development environment.
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-3 shadow-sm">
          <div className="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 font-mono font-bold flex items-center justify-center">
            02
          </div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">Initialize Tauri CLI</h3>
          <p className="text-xs text-slate-500 leading-relaxed">
            Run <code className="bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 rounded text-indigo-600 font-mono">npm install -D @tauri-apps/cli</code> and place the generated <code className="bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 rounded font-mono">src-tauri</code> files into your project root.
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-3 shadow-sm">
          <div className="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 font-mono font-bold flex items-center justify-center">
            03
          </div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">Compile Portable & Installer</h3>
          <p className="text-xs text-slate-500 leading-relaxed">
            Execute <code className="bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 rounded text-indigo-600 font-mono">cargo tauri build</code>. The `.exe` installer (NSIS) and portable `.exe` will be built in <code className="bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 rounded font-mono">src-tauri/target/release/bundle/</code>.
          </p>
        </div>
      </div>

      {/* Code Viewer for Tauri Config Files */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div className="flex flex-wrap items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
          <div className="flex items-center gap-2">
            <FileCode size={18} className="text-indigo-600 dark:text-indigo-400" />
            <span className="text-sm font-bold text-slate-900 dark:text-white font-mono">Tauri Configuration Files</span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {Object.keys(configFiles).map((filename) => (
              <button
                key={filename}
                onClick={() => setActiveFile(filename)}
                className={`px-3 py-1.5 text-xs font-mono rounded-lg transition-colors ${
                  activeFile === filename
                    ? 'bg-indigo-600 text-white font-semibold shadow'
                    : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-300 dark:hover:bg-slate-600'
                }`}
              >
                {filename}
              </button>
            ))}
          </div>
        </div>

        <div className="p-6 bg-slate-950 text-slate-100 relative">
          <button
            onClick={handleCopy}
            className="absolute top-4 right-4 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-mono rounded-lg transition-colors flex items-center gap-1.5 shadow"
          >
            {copied ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
            <span>{copied ? 'Copied!' : 'Copy Code'}</span>
          </button>

          <pre className="text-xs font-mono overflow-x-auto p-4 bg-slate-900 rounded-lg text-slate-300 leading-relaxed max-h-[400px]">
            {loading ? 'Loading Tauri configuration files...' : configFiles[activeFile]}
          </pre>
        </div>
      </div>
    </div>
  );
};
