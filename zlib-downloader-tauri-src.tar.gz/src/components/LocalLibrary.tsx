import React from 'react';
import { HardDrive, BookOpen, Trash2, FolderOpen, FileText } from 'lucide-react';
import { Book } from '../types';

interface LocalLibraryProps {
  downloadedBooks: Book[];
  onRemoveBook: (id: string) => void;
  onOpenFolder: () => void;
  onOpenAISummary: (book: Book) => void;
}

export const LocalLibrary: React.FC<LocalLibraryProps> = ({
  downloadedBooks,
  onRemoveBook,
  onOpenFolder,
  onOpenAISummary
}) => {
  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <HardDrive className="text-indigo-600" size={24} />
            <span>Local Downloaded Library ({downloadedBooks.length})</span>
          </h2>
          <p className="text-sm text-slate-500 mt-1">
            Manage your saved EPUB, PDF, and MOBI books stored locally in your desktop downloads directory.
          </p>
        </div>

        <button
          onClick={onOpenFolder}
          className="px-4 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-lg transition-colors flex items-center gap-2 shadow-sm"
        >
          <FolderOpen size={16} />
          <span>Open Library Folder</span>
        </button>
      </div>

      {downloadedBooks.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-12 text-center">
          <div className="w-12 h-12 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center mx-auto text-slate-400 mb-4">
            <BookOpen size={24} />
          </div>
          <h3 className="text-lg font-bold text-slate-900 dark:text-white">Your local library is empty</h3>
          <p className="text-sm text-slate-500 mt-1">Downloaded books will appear here automatically after download completion.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {downloadedBooks.map((book) => (
            <div
              key={book.id}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 flex flex-col justify-between hover:shadow-lg transition-all group"
            >
              <div>
                <div className="flex items-start justify-between gap-4 mb-3">
                  <div>
                    <span className="inline-block px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800 mb-1">
                      {book.extension} · {book.filesize}
                    </span>
                    <h3 className="text-base font-bold text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors line-clamp-2">
                      {book.title}
                    </h3>
                  </div>
                </div>

                <div className="flex items-center gap-2 text-xs text-slate-500 mb-3">
                  <span className="font-medium text-slate-700 dark:text-slate-300">{book.author}</span>
                  <span aria-hidden="true">·</span>
                  <span>{book.year}</span>
                </div>
              </div>

              <div className="space-y-3 pt-4 border-t border-slate-100 dark:border-slate-800">
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => onOpenAISummary(book)}
                    className="px-3 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-medium rounded-lg transition-colors flex items-center justify-center gap-1.5"
                  >
                    <BookOpen size={14} />
                    <span>Read Guide</span>
                  </button>

                  <button
                    onClick={() => onRemoveBook(book.id)}
                    className="px-3 py-2 bg-red-50 dark:bg-red-950/50 hover:bg-red-100 dark:hover:bg-red-900 text-red-600 dark:text-red-400 text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-1.5"
                  >
                    <Trash2 size={14} />
                    <span>Remove</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
