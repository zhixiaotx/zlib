import React, { useState } from 'react';
import { Settings, FolderOpen, Shield, Cpu, CheckCircle2 } from 'lucide-react';

export const SettingsTab: React.FC = () => {
  const [downloadDir, setDownloadDir] = useState('C:\\Users\\Public\\ZLibraryDownloads');
  const [concurrency, setConcurrency] = useState('3');
  const [savedToken, setSavedToken] = useState('');
  const [proxy, setProxy] = useState('DIRECT (No Proxy)');
  const [saved, setSaved] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-sm">
        <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2 mb-2">
          <Settings className="text-indigo-600" size={24} />
          <span>Desktop Downloader Preferences</span>
        </h2>
        <p className="text-sm text-slate-500 mb-6">
          Configure local storage paths, download concurrency limits, and Z-Library account session credentials.
        </p>

        <form onSubmit={handleSave} className="space-y-6">
          <div className="space-y-2">
            <label className="text-xs font-semibold uppercase tracking-wider text-slate-600 dark:text-slate-400">
              Default Download Directory
            </label>
            <div className="flex gap-3">
              <input
                type="text"
                value={downloadDir}
                onChange={(e) => setDownloadDir(e.target.value)}
                className="flex-1 px-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
              <button
                type="button"
                onClick={() => alert('Folder picker dialog simulated')}
                className="px-4 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-xl transition-colors flex items-center gap-2"
              >
                <FolderOpen size={16} />
                <span>Browse</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-xs font-semibold uppercase tracking-wider text-slate-600 dark:text-slate-400">
                Concurrent Downloads (1 - 5)
              </label>
              <select
                value={concurrency}
                onChange={(e) => setConcurrency(e.target.value)}
                className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="1">1 (Single Stream)</option>
                <option value="2">2 Concurrent Files</option>
                <option value="3">3 Concurrent Files (Recommended)</option>
                <option value="5">5 High Speed Streams</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-semibold uppercase tracking-wider text-slate-600 dark:text-slate-400">
                Network Proxy Routing
              </label>
              <select
                value={proxy}
                onChange={(e) => setProxy(e.target.value)}
                className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="DIRECT">DIRECT (No Proxy)</option>
                <option value="SOCKS5">SOCKS5 Proxy (127.0.0.1:1080)</option>
                <option value="HTTP">HTTP Proxy (127.0.0.1:8080)</option>
              </select>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-semibold uppercase tracking-wider text-slate-600 dark:text-slate-400">
              Z-Library Account Remind-Me / Session Cookie (Optional for Premium Limits)
            </label>
            <input
              type="password"
              value={savedToken}
              onChange={(e) => setSavedToken(e.target.value)}
              placeholder="Paste your remind-me cookie token here..."
              className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-800">
            {saved ? (
              <span className="flex items-center gap-1.5 text-xs text-emerald-600 font-semibold">
                <CheckCircle2 size={16} /> Preferences saved successfully
              </span>
            ) : (
              <span></span>
            )}

            <button
              type="submit"
              className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs rounded-xl shadow-lg shadow-indigo-600/30 transition-all"
            >
              Save Preferences
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
