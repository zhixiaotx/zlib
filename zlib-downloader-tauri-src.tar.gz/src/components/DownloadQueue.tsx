import React from 'react';
import { Download, Pause, Play, Trash2, CheckCircle2, AlertCircle, FolderOpen, ArrowDown } from 'lucide-react';
import { DownloadTask } from '../types';

interface DownloadQueueProps {
  tasks: DownloadTask[];
  onPauseTask: (id: string) => void;
  onResumeTask: (id: string) => void;
  onCancelTask: (id: string) => void;
  onOpenFolder: () => void;
}

export const DownloadQueue: React.FC<DownloadQueueProps> = ({
  tasks,
  onPauseTask,
  onResumeTask,
  onCancelTask,
  onOpenFolder
}) => {
  const activeCount = tasks.filter(t => t.status === 'downloading').length;
  const completedCount = tasks.filter(t => t.status === 'completed').length;

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Download className="text-indigo-600" size={24} />
            <span>Download Queue & Real-Time Progress</span>
          </h2>
          <p className="text-sm text-slate-500 mt-1">
            Active: <span className="font-semibold text-indigo-600 dark:text-indigo-400">{activeCount}</span> · Completed: <span className="font-semibold text-emerald-600 dark:text-emerald-400">{completedCount}</span>
          </p>
        </div>

        <button
          onClick={onOpenFolder}
          className="px-4 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-lg transition-colors flex items-center gap-2 shadow-sm"
        >
          <FolderOpen size={16} />
          <span>Open Download Directory</span>
        </button>
      </div>

      {/* Tasks List */}
      {tasks.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-12 text-center">
          <div className="w-12 h-12 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center mx-auto text-slate-400 mb-4">
            <ArrowDown size={24} />
          </div>
          <h3 className="text-lg font-bold text-slate-900 dark:text-white">No active downloads</h3>
          <p className="text-sm text-slate-500 mt-1">Search for books in the search tab and click Download to start streaming.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {tasks.map((task) => (
            <div
              key={task.id}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm space-y-4"
            >
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800">
                      {task.extension}
                    </span>
                    <span className="text-xs text-slate-500 font-mono">Mirror: {task.mirrorUrl}</span>
                  </div>
                  <h4 className="text-base font-bold text-slate-900 dark:text-white">{task.title}</h4>
                  <p className="text-xs text-slate-500">{task.author} · {task.filesize}</p>
                </div>

                <div className="flex items-center gap-2">
                  {task.status === 'downloading' && (
                    <button
                      onClick={() => onPauseTask(task.id)}
                      className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition-colors"
                      title="Pause"
                    >
                      <Pause size={16} />
                    </button>
                  )}
                  {task.status === 'paused' && (
                    <button
                      onClick={() => onResumeTask(task.id)}
                      className="p-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white transition-colors"
                      title="Resume"
                    >
                      <Play size={16} />
                    </button>
                  )}
                  <button
                    onClick={() => onCancelTask(task.id)}
                    className="p-2 rounded-lg bg-red-50 dark:bg-red-950/50 hover:bg-red-100 dark:hover:bg-red-900 text-red-600 dark:text-red-400 transition-colors"
                    title="Remove"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>

              {/* Progress Bar & Status */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs font-mono">
                  <div className="flex items-center gap-2">
                    {task.status === 'completed' && (
                      <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-semibold">
                        <CheckCircle2 size={14} /> Completed
                      </span>
                    )}
                    {task.status === 'downloading' && (
                      <span className="flex items-center gap-1 text-indigo-600 dark:text-indigo-400 font-semibold">
                        <span className="w-2 h-2 rounded-full bg-indigo-600 animate-ping"></span>
                        Downloading... {task.speed}
                      </span>
                    )}
                    {task.status === 'paused' && (
                      <span className="flex items-center gap-1 text-amber-500 font-semibold">
                        <Pause size={14} /> Paused
                      </span>
                    )}
                  </div>
                  <div className="text-slate-500">
                    {task.downloadedBytes} / {task.filesize} ({task.progress}%) {task.status === 'downloading' && `· ETA: ${task.eta}`}
                  </div>
                </div>

                <div className="w-full bg-slate-100 dark:bg-slate-800 h-3 rounded-full overflow-hidden p-0.5 border border-slate-200 dark:border-slate-700">
                  <div
                    className={`h-full rounded-full transition-all duration-300 ${
                      task.status === 'completed'
                        ? 'bg-emerald-500'
                        : task.status === 'paused'
                        ? 'bg-amber-500'
                        : 'bg-gradient-to-r from-indigo-500 to-violet-600'
                    }`}
                    style={{ width: `${task.progress}%` }}
                  ></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
