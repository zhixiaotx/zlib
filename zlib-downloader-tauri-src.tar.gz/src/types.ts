export interface Book {
  id: string;
  title: string;
  author: string;
  year: string;
  publisher: string;
  extension: string;
  filesize: string;
  language: string;
  rating: number;
  coverUrl: string;
  description: string;
  downloadsCount: number;
}

export interface DownloadTask {
  id: string;
  bookId: string;
  title: string;
  author: string;
  extension: string;
  filesize: string;
  progress: number; // 0 - 100
  speed: string;
  eta: string;
  status: 'downloading' | 'paused' | 'completed' | 'failed';
  downloadedBytes: string;
  mirrorUrl: string;
}

export interface Mirror {
  id: string;
  url: string;
  status: 'online' | 'unstable' | 'offline';
  latency: string;
  active: boolean;
}
