import express from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

const app = express();
app.use(express.json());

// Initialize GoogleGenAI server-side client
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || "",
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

// Mock initial Z-Library database for search & download
interface Book {
  id: string;
  title: string;
  author: string;
  year: string;
  publisher: string;
  extension: string;
  filesize: string;
  language: string;
  rating: number;
  coverUrl: string;
  description: string;
  downloadsCount: number;
}

let mockBooks: Book[] = [
  {
    id: "zlib-1",
    title: "Designing Data-Intensive Applications",
    author: "Martin Kleppmann",
    year: "2017",
    publisher: "O'Reilly Media",
    extension: "pdf",
    filesize: "35.4 MB",
    language: "English",
    rating: 4.9,
    coverUrl: "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=600&q=80",
    description: "The Big Ideas Behind Reliable, Scalable, and Maintainable Systems. Essential reading for backend and distributed systems engineers.",
    downloadsCount: 142850
  },
  {
    id: "zlib-2",
    title: "Clean Code: A Handbook of Agile Software Craftsmanship",
    author: "Robert C. Martin",
    year: "2008",
    publisher: "Prentice Hall",
    extension: "epub",
    filesize: "18.2 MB",
    language: "English",
    rating: 4.7,
    coverUrl: "https://images.unsplash.com/photo-1532012197267-da84d127e765?auto=format&fit=crop&w=600&q=80",
    description: "Even bad code can function. But if code isn't clean, it can bring a development organization to its knees.",
    downloadsCount: 230910
  },
  {
    id: "zlib-3",
    title: "Deep Learning (Adaptive Computation and Machine Learning series)",
    author: "Ian Goodfellow, Yoshua Bengio, Aaron Courville",
    year: "2016",
    publisher: "MIT Press",
    extension: "pdf",
    filesize: "48.9 MB",
    language: "English",
    rating: 4.8,
    coverUrl: "https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?auto=format&fit=crop&w=600&q=80",
    description: "An introduction to a broad range of topics in deep learning, covering mathematical and conceptual background.",
    downloadsCount: 98400
  },
  {
    id: "zlib-4",
    title: "The Pragmatic Programmer: Your Journey to Mastery",
    author: "David Thomas, Andrew Hunt",
    year: "2019",
    publisher: "Addison-Wesley Professional",
    extension: "epub",
    filesize: "12.1 MB",
    language: "English",
    rating: 4.9,
    coverUrl: "https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=600&q=80",
    description: "Straight from the programming trenches, The Pragmatic Programmer cuts through the increasing specialization and technical variety of modern software development.",
    downloadsCount: 175600
  },
  {
    id: "zlib-5",
    title: "Rust Programming Language, 2nd Edition",
    author: "Steve Klabnik, Carol Nichols",
    year: "2023",
    publisher: "No Starch Press",
    extension: "pdf",
    filesize: "24.6 MB",
    language: "English",
    rating: 4.9,
    coverUrl: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=600&q=80",
    description: "The official book on the Rust programming language, empowering you to write faster, more reliable software.",
    downloadsCount: 84200
  },
  {
    id: "zlib-6",
    title: "重构：改善既有代码的设计（第2版）",
    author: "Martin Fowler",
    year: "2019",
    publisher: "人民邮电出版社",
    extension: "pdf",
    filesize: "52.3 MB",
    language: "Chinese",
    rating: 4.8,
    coverUrl: "https://images.unsplash.com/photo-1497633762265-9d179a990aa6?auto=format&fit=crop&w=600&q=80",
    description: "大师经典名著，清晰揭示重构的过程，解释何时和如何应该开始重构，以及如何 DCI 设计。",
    downloadsCount: 112000
  }
];

// Active mirrors list
let mirrors = [
  { id: "m-1", url: "https://singlelogin.re", status: "online", latency: "142ms", active: true },
  { id: "m-2", url: "https://z-lib.is", status: "online", latency: "198ms", active: false },
  { id: "m-3", url: "https://z-lib.fm", status: "online", latency: "235ms", active: false },
  { id: "m-4", url: "https://1lib.sk", status: "unstable", latency: "650ms", active: false }
];

// API: Search books
app.get("/api/zlib/search", (req, res) => {
  const query = (req.query.q as string || "").toLowerCase();
  const lang = req.query.lang as string || "all";
  const ext = req.query.ext as string || "all";

  let results = mockBooks.filter(b => {
    const matchQuery = !query || b.title.toLowerCase().includes(query) || b.author.toLowerCase().includes(query) || b.publisher.toLowerCase().includes(query);
    const matchLang = lang === "all" || b.language.toLowerCase() === lang.toLowerCase();
    const matchExt = ext === "all" || b.extension.toLowerCase() === ext.toLowerCase();
    return matchQuery && matchLang && matchExt;
  });

  res.json({ success: true, books: results, total: results.length });
});

// API: Get mirrors
app.get("/api/zlib/mirrors", (req, res) => {
  res.json({ success: true, mirrors });
});

// API: Test mirrors
app.post("/api/zlib/mirrors/test", (req, res) => {
  mirrors = mirrors.map(m => {
    const latencyVal = Math.floor(80 + Math.random() * 300);
    return {
      ...m,
      status: latencyVal < 400 ? "online" : "unstable",
      latency: `${latencyVal}ms`
    };
  });
  res.json({ success: true, mirrors });
});

// API: Gemini book summary & recommendation
app.post("/api/gemini/summary", async (req, res) => {
  try {
    const { title, author, description } = req.body;
    
    if (!process.env.GEMINI_API_KEY) {
      return res.status(400).json({ 
        success: false, 
        error: "Gemini API key not configured. Please set GEMINI_API_KEY in Settings > Secrets." 
      });
    }

    const prompt = `Provide a comprehensive professional summary, key takeaways, and reading guide for the book "${title}" by ${author}. Description: "${description}". Format the response in clear sections: Overview, Key Core Concepts, Target Audience, and Study/Reading Recommendations.`;

    const response = await ai.models.generateContent({
      model: "gemini-4-hydrogen",
      contents: prompt,
      config: {
        systemInstruction: "You are an expert literary scholar and technical book reviewer. Provide insightful, structured summaries."
      }
    });

    res.json({ success: true, summary: response.text });
  } catch (err: any) {
    console.error("Gemini summary error:", err);
    res.status(500).json({ success: false, error: err.message || "Failed to generate AI summary" });
  }
});

// API: Tauri template files generator (for portable .exe & installer)
app.get("/api/tauri/config-files", (req, res) => {
  const tauriConfJson = {
    "$schema": "../node_modules/@tauri-apps/cli/schema.json",
    "productName": "zlib-downloader",
    "version": "1.2.0",
    "identifier": "com.zlib.desktop.app",
    "build": {
      "devPath": "http://localhost:3000",
      "distDir": "../dist"
    },
    "bundle": {
      "active": true,
      "targets": ["all"],
      "icon": [
        "icons/32x32.png",
        "icons/128x128.png",
        "icons/128x128@2x.png",
        "icons/icon.icns",
        "icons/icon.ico"
      ],
      "windows": {
        "certificateSmarts": null,
        "nsis": {
          "installerIcon": "icons/icon.ico",
          "headerImage": null,
          "displayLanguageSelector": false,
          "shortcutName": "Z-Library Downloader"
        }
      }
    }
  };

  const cargoToml = `[package]
name = "zlib-downloader"
version = "1.2.0"
description = "High-performance Z-Library Desktop Downloader with Tauri"
authors = ["Zlib Open Source Contributors"]
edition = "2021"

[build-dependencies]
tauri-build = { version = "1.5", features = [] }

[dependencies]
serde = { version = "1.0", features = ["derive"] }
serde_json = "1.0"
tauri = { version = "1.5", features = ["protocol-asset", "shell-open", "dialog-all", "fs-all", "http-all"] }
tokio = { version = "1", features = ["full"] }
reqwest = { version = "0.11", features = ["json", "stream"] }

[features]
default = ["custom-protocol"]
custom-protocol = ["tauri/custom-protocol"]
`;

  const mainRs = `// Prevents additional console window on Windows in release, DO NOT REMOVE!!
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
  tauri::Builder::default()
    .invoke_handler(tauri::generate_handler![])
    .run(tauri::generate_context!())
    .expect("error while running tauri application");
}
`;

  const buildScript = `@echo off
echo Building Z-Library Downloader Tauri App (.exe portable & installer)...
npm run build
cargo tauri build
echo Build completed! Check src-tauri/target/release/bundle/ for .exe installer and portable files.
pause
`;

  res.json({
    success: true,
    files: {
      "src-tauri/tauri.conf.json": JSON.stringify(tauriConfJson, null, 2),
      "src-tauri/Cargo.toml": cargoToml,
      "src-tauri/src/main.rs": mainRs,
      "build_tauri.bat": buildScript
    }
  });
});

if (process.env.NODE_ENV !== "production") {
  const { createServer: createViteServer } = await import("vite");
  const vite = await createViteServer({
    server: { middlewareMode: true, hmr: process.env.DISABLE_HMR !== 'true' }
  });
  app.use(vite.middlewares);
} else {
  const distPath = path.resolve(__dirname, "dist");
  app.use(express.static(distPath));
  app.get("*", (req, res) => {
    res.sendFile(path.resolve(distPath, "index.html"));
  });
}

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
